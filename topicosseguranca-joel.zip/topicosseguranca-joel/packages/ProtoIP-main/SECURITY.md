# Security Policy

## Supported Versions

As of now, ProtoIP 

| Version | Supported          |
| ------- | ------------------ |
| 0.9.0   | :x: |
| 0.9.1   | :x:                |
| 0.9.2   | :white_check_mark: |

## Reporting a Vulnerability

If you encounter a vulnerability that you cannot solve yourself, or that may require additional intervention, please create a new [issue](https://github.com/JoaoAJMatos/ProtoIP/issues/new) under the `vuln` tag.

Depending on the severity of the vulnerability a new patch will be out within a day or two.
